package com.myweb.ctrl;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.myweb.domain.ProductVO;
import com.myweb.service.ProductService;

@Controller
@RequestMapping("/product/*")
public class ProductCtrl {
	private static final Logger log = LoggerFactory.getLogger(ProductCtrl.class);
	@Inject
	private ProductService psv;
	
//	@RequestMapping(value = "/write", method=RequestMethod.GET)
	@GetMapping("/write")
	public void write() {
		log.info(">>> 상품 등록 페이지 출력 - GET ");
	}
//	@RequestMapping(value = "/write", method=RequestMethod.POST)
	@PostMapping("/write")
	public String write(ProductVO pvo, @RequestParam("imgfile")String imgfile, RedirectAttributes reAttr) {
		log.info(">>> 상품 등록 페이지 출력 - GET ");
		psv.write(pvo);
		reAttr.addFlashAttribute("result", "write_ok"); // 한번 전송되면 자바 메모리에서 사라짐
		return "redirect:/product/list";
	}
	
//	@RequestMapping(value = "/list", method=RequestMethod.GET)
	@GetMapping("/list")
	public void list(Model model) {	// 화면에 뿌릴거니까 Model 필요
		log.info(">>> list 출력 - GET ");
//		List<ProductVO> list = new ArrayList<>();
//		list = psv.list();
		model.addAttribute("list", psv.list());
	}
	
	@GetMapping({"/detail", "/modify"})
	public void detail(@RequestParam("pno")int pno, Model model) {
		log.info(">>> 상품 상세 페이지 출력 - GET");
		model.addAttribute("pvo", psv.detail(pno));
	}
	
/*	@GetMapping("/modify")
	public void modify(@RequestParam("pno")int pno, Model model) {
		log.info(">>> 상품 수정 페이지 출력 - GET");
		model.addAttribute("pvo", psv.detail(pno));
	}*/
	
	@PostMapping("/modify")
	public String modify(ProductVO pvo, RedirectAttributes reAttr) {
		log.info(">>> 상품 수정 요청 - POST");
		psv.modify(pvo);
		reAttr.addFlashAttribute("result", "modify_ok");
		return "redirect:/product/detail?pno="+pvo.getPno();
	}
	
	@PostMapping("/remove")
	public String remove(@RequestParam("pno")int pno, RedirectAttributes reAttr) {
		log.info(">>> 상품 삭제 - POST");
		psv.remove(pno);
		reAttr.addFlashAttribute("result", "remove_ok");
		return "redirect:/product/list";
		
	}
}
